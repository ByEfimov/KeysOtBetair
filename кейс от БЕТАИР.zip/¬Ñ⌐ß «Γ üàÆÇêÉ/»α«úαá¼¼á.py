vis = int(input('Введите высоту поля '))
shir = int(input('Введите ширину поля '))
inp = str(input('Введите вход '))
out = str(input('Введите вывод '))
put = list()
x = 0
y = int(inp)
clh = [9]
clp = 'i'

def lv_o():
    a = 0
    while (str(y) + str(x)) in clh:
        x = x - 1
        put.append(str(y) + str(x))
        if x < shir:
            a = 1
    y = y + 1
    put.append(str(y) + str(x))
    while (str(y) + str(x + 1)) in clh:
        y = y + 1
        put.append(str(y) + str(x))
        if y > vis + 1:
            a = 1

    while x < int(out):
        x = x + 1
        put.append(str(y) + str(x))

    while y < vis:
        y = y + 1
        put.append(str(y) + str(x))
    if a == 1:
        print('Ошибка')
    else:
        put.append(out)
        print(put)

while clp != '':           # Введение пользователем
    clp = str(input('Ключ ')) #неисправных ключей
    clh.append(clp)# и их сохранение в список clh
while x < int(out):
    x = x+1
    put.append(str(y)+str(x))
if (str(y) + str(x)) in clh:
    if x < 2:
        a = 0
        while (str(y) + str(x)) in clh:
             x = x + 1
             put.append(str(y)+str(x))
             if x > shir:
                 a = 1

        y = y + 1
        put.append(str(y)+str(x))
        while (str(y) + str(x - 1)) in clh:
            y = y + 1
            put.append(str(y)+str(x))
            if y > vis + 1:
                a = 1

        while x > int(out):
            x = x - 1
            put.append(str(y)+str(x))

        while y < vis:
            y = y + 1
            put.append(str(y) + str(x))
        if a == 1:
            print('Ошибка')
        else:
            put.append(out)
            print(put)
    elif x > 1 and x < shir - 1:
        a = 0
        while (str(y) + str(x)) in clh:
            x = x + 1
            put.append(str(y) + str(x))
            if x > shir:
                a = 1

        y = y + 1
        put.append(str(y) + str(x))
        while (str(y) + str(x - 1)) in clh:
            y = y + 1
            put.append(str(y) + str(x))
            if y > vis + 1:
                a = 1

        while x > int(out):
            x = x - 1
            put.append(str(y) + str(x))

        while y < vis:
            y = y + 1
            put.append(str(y) + str(x))
        if a == 1:
            while x > int(out):
                x = x-1
            lv_o()
        else:
            print(put)
    else:
        lv_o()

else:
    put = [(str(y) + str(x))]
    print(put)